#include <stdio.h>

int gi;

int f();
int g();


int main() {


	gi = f(10, 132, 132, 56);

	printf("gi = %d\n", gi);

    return 0;
}

int f() {
/* int f(short ps1, unsigned char puc1, char pc1, int pi1) {
	short ls1;
	unsigned char luc1;
	char lc1;
	int li1;

	ls1 = g(ps1, puc1, pc1, pi1);

    li1 = pc1 + pi1;
    luc1 = pi1 + 100;
    lc1 = li1 + ls1 + luc1;


    return gi + ls1 - luc1 - lc1; */
    _asm{
		// complete your code here
		


		mov eax, DWORD PTR [ebp - 32]  // pi1 -> eax
		push eax					  //push eax onto stack
		movsx eax, BYTE PTR[ebp - 28] //  pc1 -> stack
		push eax					  //push eax onto stack
		movzx eax, BYTE PTR[ebp - 24] //puc1 -> eax 
		push eax					  //push eax onto stack
		movsx eax, WORD PTR[ebp - 20]  //ps1 -> eax		
		push eax						//push eax onto stack
		call g							//call function g 
		move WORD PTR[ebp - 2], ax  
		


		//li1 = pc1 + pi1;
		movsx eax, BYTE PTR [ebp - 28] //pc1 -> eax
		add eax , DWORD PTR[ebp - 32] // add pi1 -> eax
		mov DWORD PTR[ebp - 8], eax   //move eax -> li1

		//luc1 = pi1 + 100;
		mov eax, DWORD PTR[ebp - 32]  //pi1 -> eax
		add eax, 100				// add 100 -> eax
		mov WORD PTR[ebp - 10], eax   // luc1 -> eax

		//lc1 = li1 + ls1 + luc1;
		mov eax, dword ptr[ebp - 8] //li1 -> eax
		movsx ecx, word ptr[ebp - 16] //ls1 -> ecx
		add eax, ecx				//add ecx -> eax
		movzx ecx, byte ptr[ebp - 10]  //luc1 -> ecx
		add eax, ecx					// add ecx -> eax
		mov byte ptr[ebp - 9], al    //add value into lc1

		//return gi + ls1 - luc1 - lc1;
		movsx ecx, byte ptr[ebp - 16] //ls1 -> ecx
		mov eax, DWORD PTR gi        //g1 -> eax
		add eax, ecx

		movsx ecx, byte ptr[ebp - 10]  //luc1 -> ecx
		sub eax, ecx					//sub eax by ecx

		movsx ecx, word ptr[ebp - 9] //lc1 -> ecx
		sub eax, ecx				//sub eax by ecx
		
		push eax
		add  esp, 32
		pop  ebp


	}
}

int g(int x1, int x2, int x3, int x4) {
	printf("x1 = %d\tx2 = %d\tx3 = %d\tx4 = %d\n", x1, x2, x3, x4);
	gi = x1 - x3;
	return gi + x2 - x4;
}


