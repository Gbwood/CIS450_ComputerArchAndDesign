#include <stdio.h>

int f();
int g();

int x, y;

int main() {
/* int main(int argc, char **argv, char **envp) {
	int i, j; // i = -4 j = -8
	j = 0;

	for(i = 10 ; i < 30; i++) {
		if (i < 20) {
			j += i;
		} else {
			j -= i;
		}
	 } 
	 x = i;
     y = j; */

    _asm {
		mov DWORD PTR[rbp - 4], 0  // move 0 -> j
		mov DWORD PTR[rbp - 8], 10 // move 10 -> j
		jmp SHORT L2


		//if (i < 20)
	L5: cmp DWORD PTR[rbp - 8], 19   
		jg SHORT L3
		mov eax, DWORD PTR[rbp - 8]
		add DWORD PTR[rbp - 4], eax
		jmp SHORT L4
		
		//j += i;
		mov eax, DWORD PTR[rbp - 8] //i -> eax
		add DWORD PTR[rbp - 4], eax //add eax -> j
		jmp SHORT L4

	L3: mov eax, DWORD PTR[rbp - 8] // i -> eax
		sub DWORD PTR[rbp - 4], eax  //sub eax -> j

	L4: add DWORD PTR[rbp - 8], 1 // add 1 to i
	

		//while (i < 30) {
	L5: cmp DWORD PTR[rbp - 8], 29 // i - 0 < 29
		jle SHORT L5

		mov eax, DWORD PTR[rbp - 8] //i -> eax
		mov DWORD PTR x, eax   //eax -> x
		mov eax, DWORD PTR[rbp - 4]  //j -> eax
		mov DWORD PTR y, eax //eax -> j

	}
	printf("i = %d\tj = %d\n", x, y);
}