int a[3][2][2][2];

// declare d, f, h;
int *(*d)[2][2]; // for your reference: variable d and virtual array c
int  **(*f)[2];
int  ****h;

void main() {
	int i, j, k, m;
	int dummy;

	dummy = d[i][j][k][m];
	dummy = f[i][j][k][m];
	dummy = h[i][j][k][m];
}