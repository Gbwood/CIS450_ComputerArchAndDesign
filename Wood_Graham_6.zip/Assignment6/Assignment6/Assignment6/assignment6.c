#include <stdio.h>
#include <stdlib.h>

int a[3][2][2][2] = { 1,2,3,4,5,6,7,8,9,10,11,12,
   13,14,15,16,17,18, 19, 20, 21, 22, 23, 24 };

// declare variables d, f, h, j, o, q, m in bss
int *(*d)[2][2]; // for your reference: variable d and virtual array c
int  **(*f)[2];
int  ****h;
int *(**j)[2];
int(*(*o)[2])[2];
int(***q)[2];
int(**m)[2][2];

void main() {
	int ii, jj, kk, mm;
	int dummy;

	// allocate virutal array c in heap,
	// point it by "d", and initialize it using "d" and "a"
	d = (int *(*)[2][2]) malloc(sizeof(int *[3][2][2]));
	for (ii = 0; ii < 3; ii++)
		for (jj = 0; jj < 2; jj++)
			for (kk = 0; kk < 2; kk++)
				d[ii][jj][kk] = a[ii][jj][kk];


	f = (int **(*)[2]) malloc(sizeof(int *(*[3][2])[3]));
	for (ii = 0; ii < 3; ii++)
		for (jj = 0; jj < 2; jj++)
			f[ii][jj] = d[ii][jj];

	h = (int  ****)malloc(sizeof(int(**[3])[2]));
	for (ii = 0; ii < 3; ii++)
		h[ii] = f[ii];

	j = (int *(**)[2]) malloc(sizeof(int *(*[3])[3]));
	for (ii = 0; ii < 3; ii++)
		j[ii] = d[ii];

	o = (int(*(*)[2])[2]) malloc(sizeof(int *[3][2]));
	for (ii = 0; ii < 3; ii++)
		for (jj = 0; jj < 2; jj++)
			o[ii][jj] = a[ii][jj];

	q = (int(***)[2]) malloc(sizeof(int(**[3])[2]));
	for (ii = 0; ii < 3; ii++)
		q[ii] = o[ii];

	m = (int(**)[2][2])malloc(sizeof(int(*[3])[2][2]));
	for (ii = 0; ii < 3; ii++)
		m[ii] = a[ii];


	for (ii = 0; ii < 3; ii++)
		for (jj = 0; jj < 2; jj++)
			for (kk = 0; kk < 2; kk++)
				for (mm = 0; mm < 2; mm++) {
					printf("%d\t", a[ii][jj][kk][mm]);
					printf("%d\t", d[ii][jj][kk][mm]);
					printf("%d\t", f[ii][jj][kk][mm]);
					printf("%d\t", h[ii][jj][kk][mm]);
					printf("%d\t", j[ii][jj][kk][mm]);
					printf("%d\t", m[ii][jj][kk][mm]);
					printf("%d\t", o[ii][jj][kk][mm]);
					printf("%d\t", q[ii][jj][kk][mm]);
					printf("\n");
				}
	scanf_s("%d", &dummy);
}
