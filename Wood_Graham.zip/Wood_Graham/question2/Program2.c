static int y = 20;
unsigned int x;

int main(int argc, char **argv, char **envp) {
	int j, i;

	i = 20; 

	while (i <= 30) {
		i = (i * y) + 33; //idk about this line

		if (x <= 20) {
			j = x;

		}
		else {
			j = x + 2;
		}

		i = i + 1;
	}

	return 0;



}
