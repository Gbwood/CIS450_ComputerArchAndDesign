#include LIBCMT;
#include OLDNAMES;

unsigned int i;
char c1;
static int j = 3;
static int m = 1;

//How and where?
static int o;
static int p = 7;


printf();
trace_me(int p, int o);

int main(int argc, char **argv, char **envp) {
	c1 = 2;

	trace_me(m, 2);
	return 0;
}



trace_me(char uc, int param1, int param2) {
	int n = 3;
	
	m = m + 1;
	if (param1 == 0) {
		printf(p, o, n, param2, param1);
		return 0;
	}
	else {
		o = o + 1;
		p = p + 1;
		param2 = param2 + 1
		trace_me(c1 + 1, param2, param1 - 1);
	}
	return 0;
}